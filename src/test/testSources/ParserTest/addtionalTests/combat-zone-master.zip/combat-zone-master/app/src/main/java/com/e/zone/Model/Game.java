package com.e.zone.Model;

public class Game {

    String data1;
    String data2;
    String data3;
    String data4;
    String data5;
    String data6;
    String data7;

    public String getData1() {
        return data1;
    }

    public void setData1(String data1) {
        this.data1 = data1;
    }

    public String getData2() {
        return data2;
    }

    public void setData2(String data2) {
        this.data2 = data2;
    }

    public String getData3() {
        return data3;
    }

    public void setData3(String data3) {
        this.data3 = data3;
    }

    public String getData4() {
        return data4;
    }

    public void setData4(String data4) {
        this.data4 = data4;
    }

    public String getData5() {
        return data5;
    }

    public void setData5(String data5) {
        this.data5 = data5;
    }

    public String getData6() {
        return data6;
    }

    public void setData6(String data6) {
        this.data6 = data6;
    }

    public String getData7() {
        return data7;
    }

    public void setData7(String data7) {
        this.data7 = data7;
    }

    public String getData8() {
        return data8;
    }

    public void setData8(String data8) {
        this.data8 = data8;
    }

    public String getData9() {
        return data9;
    }

    public void setData9(String data9) {
        this.data9 = data9;
    }

    public String getData10() {
        return data10;
    }

    public void setData10(String data10) {
        this.data10 = data10;
    }

    public String getData11() {
        return data11;
    }

    public void setData11(String data11) {
        this.data11 = data11;
    }

    public String getData12() {
        return data12;
    }

    public void setData12(String data12) {
        this.data12 = data12;
    }

    public String getData13() {
        return data13;
    }

    public void setData13(String data13) {
        this.data13 = data13;
    }

    public String getData14() {
        return data14;
    }

    public void setData14(String data14) {
        this.data14 = data14;
    }

    public String getData15() {
        return data15;
    }

    public void setData15(String data15) {
        this.data15 = data15;
    }

    public String getData16() {
        return data16;
    }

    public void setData16(String data16) {
        this.data16 = data16;
    }

    public String getData17() {
        return data17;
    }

    public void setData17(String data17) {
        this.data17 = data17;
    }

    public String getData18() {
        return data18;
    }

    public void setData18(String data18) {
        this.data18 = data18;
    }

    public String getData19() {
        return data19;
    }

    public void setData19(String data19) {
        this.data19 = data19;
    }

    public String getData20() {
        return data20;
    }

    public void setData20(String data20) {
        this.data20 = data20;
    }

    public String getData21() {
        return data21;
    }

    public void setData21(String data21) {
        this.data21 = data21;
    }

    public String getData22() {
        return data22;
    }

    public void setData22(String data22) {
        this.data22 = data22;
    }

    String data8;
    String data9;
    String data10;
    String data11;
    String data12;
    String data13;
    String data14;
    String data15;
    String data16;
    String data17;
    String data18;
    String data19;
    String data20;
    String data21;
    String data22;

    String total_players;

    public String getTotal_players() {
        return total_players;
    }

    public void setTotal_players(String total_players) {
        this.total_players = total_players;
    }

    public String getJoined_players() {
        return joined_players;
    }

    public void setJoined_players(String joined_players) {
        this.joined_players = joined_players;
    }

    String joined_players;
    String rule1;
    String rule2;

    public String getRule1() {
        return rule1;
    }

    public void setRule1(String rule1) {
        this.rule1 = rule1;
    }

    public String getRule2() {
        return rule2;
    }

    public void setRule2(String rule2) {
        this.rule2 = rule2;
    }

    public String getEntry_fee() {
        return entry_fee;
    }

    public void setEntry_fee(String entry_fee) {
        this.entry_fee = entry_fee;
    }

    String entry_fee;

    public String getGame_id() {
        return game_id;
    }

    public void setGame_id(String game_id) {
        this.game_id = game_id;
    }

    String game_id;

    String room_id;
    String room_password;
    String room_slot;

    public String getRoom_id() {
        return room_id;
    }

    public void setRoom_id(String room_id) {
        this.room_id = room_id;
    }

    public String getRoom_password() {
        return room_password;
    }

    public void setRoom_password(String room_password) {
        this.room_password = room_password;
    }

    public String getRoom_slot() {
        return room_slot;
    }

    public void setRoom_slot(String room_slot) {
        this.room_slot = room_slot;
    }

    public String getRoom_message() {
        return room_message;
    }

    public void setRoom_message(String room_message) {
        this.room_message = room_message;
    }

    String room_message;

    public String getGamename() {
        return gamename;
    }

    public void setGamename(String gamename) {
        this.gamename = gamename;
    }

    String gamename;


    String row1_rank;
    String row2_rank;

    public String getRow1_rank() {
        return row1_rank;
    }

    public void setRow1_rank(String row1_rank) {
        this.row1_rank = row1_rank;
    }

    public String getRow2_rank() {
        return row2_rank;
    }

    public void setRow2_rank(String row2_rank) {
        this.row2_rank = row2_rank;
    }

    public String getRow3_rank() {
        return row3_rank;
    }

    public void setRow3_rank(String row3_rank) {
        this.row3_rank = row3_rank;
    }

    public String getRow4_rank() {
        return row4_rank;
    }

    public void setRow4_rank(String row4_rank) {
        this.row4_rank = row4_rank;
    }

    public String getRow5_rank() {
        return row5_rank;
    }

    public void setRow5_rank(String row5_rank) {
        this.row5_rank = row5_rank;
    }

    public String getRow6_rank() {
        return row6_rank;
    }

    public void setRow6_rank(String row6_rank) {
        this.row6_rank = row6_rank;
    }

    public String getRow7_rank() {
        return row7_rank;
    }

    public void setRow7_rank(String row7_rank) {
        this.row7_rank = row7_rank;
    }

    public String getRow8_rank() {
        return row8_rank;
    }

    public void setRow8_rank(String row8_rank) {
        this.row8_rank = row8_rank;
    }

    public String getRow9_rank() {
        return row9_rank;
    }

    public void setRow9_rank(String row9_rank) {
        this.row9_rank = row9_rank;
    }

    public String getRow10_rank() {
        return row10_rank;
    }

    public void setRow10_rank(String row10_rank) {
        this.row10_rank = row10_rank;
    }

    public String getRow1_price() {
        return row1_price;
    }

    public void setRow1_price(String row1_price) {
        this.row1_price = row1_price;
    }

    public String getRow2_price() {
        return row2_price;
    }

    public void setRow2_price(String row2_price) {
        this.row2_price = row2_price;
    }

    public String getRow3_price() {
        return row3_price;
    }

    public void setRow3_price(String row3_price) {
        this.row3_price = row3_price;
    }

    public String getRow4_price() {
        return row4_price;
    }

    public void setRow4_price(String row4_price) {
        this.row4_price = row4_price;
    }

    public String getRow5_price() {
        return row5_price;
    }

    public void setRow5_price(String row5_price) {
        this.row5_price = row5_price;
    }

    public String getRow6_price() {
        return row6_price;
    }

    public void setRow6_price(String row6_price) {
        this.row6_price = row6_price;
    }

    public String getRow7_price() {
        return row7_price;
    }

    public void setRow7_price(String row7_price) {
        this.row7_price = row7_price;
    }

    public String getRow8_price() {
        return row8_price;
    }

    public void setRow8_price(String row8_price) {
        this.row8_price = row8_price;
    }

    public String getRow9_price() {
        return row9_price;
    }

    public void setRow9_price(String row9_price) {
        this.row9_price = row9_price;
    }

    public String getRow10_price() {
        return row10_price;
    }

    public void setRow10_price(String row10_price) {
        this.row10_price = row10_price;
    }

    String row3_rank;
    String row4_rank;
    String row5_rank;
    String row6_rank;
    String row7_rank;
    String row8_rank;
    String row9_rank;
    String row10_rank;
    String row1_price,row2_price,row3_price,row4_price,row5_price,row6_price,row7_price,row8_price,row9_price,row10_price;
}
