package com.e.zone.Model;

public class Result {

    String gamename,date;
    String row1_rank,row1_name,row1_price;
    String row2_rank,row2_name,row2_price;
    String row3_rank,row3_name,row3_price;
    String row4_rank,row4_name,row4_price;
    String row5_rank,row5_name,row5_price;
    String row6_rank;
    String row6_name;

    public String getGamename() {
        return gamename;
    }

    public void setGamename(String gamename) {
        this.gamename = gamename;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRow1_rank() {
        return row1_rank;
    }

    public void setRow1_rank(String row1_rank) {
        this.row1_rank = row1_rank;
    }

    public String getRow1_name() {
        return row1_name;
    }

    public void setRow1_name(String row1_name) {
        this.row1_name = row1_name;
    }

    public String getRow1_price() {
        return row1_price;
    }

    public void setRow1_price(String row1_price) {
        this.row1_price = row1_price;
    }

    public String getRow2_rank() {
        return row2_rank;
    }

    public void setRow2_rank(String row2_rank) {
        this.row2_rank = row2_rank;
    }

    public String getRow2_name() {
        return row2_name;
    }

    public void setRow2_name(String row2_name) {
        this.row2_name = row2_name;
    }

    public String getRow2_price() {
        return row2_price;
    }

    public void setRow2_price(String row2_price) {
        this.row2_price = row2_price;
    }

    public String getRow3_rank() {
        return row3_rank;
    }

    public void setRow3_rank(String row3_rank) {
        this.row3_rank = row3_rank;
    }

    public String getRow3_name() {
        return row3_name;
    }

    public void setRow3_name(String row3_name) {
        this.row3_name = row3_name;
    }

    public String getRow3_price() {
        return row3_price;
    }

    public void setRow3_price(String row3_price) {
        this.row3_price = row3_price;
    }

    public String getRow4_rank() {
        return row4_rank;
    }

    public void setRow4_rank(String row4_rank) {
        this.row4_rank = row4_rank;
    }

    public String getRow4_name() {
        return row4_name;
    }

    public void setRow4_name(String row4_name) {
        this.row4_name = row4_name;
    }

    public String getRow4_price() {
        return row4_price;
    }

    public void setRow4_price(String row4_price) {
        this.row4_price = row4_price;
    }

    public String getRow5_rank() {
        return row5_rank;
    }

    public void setRow5_rank(String row5_rank) {
        this.row5_rank = row5_rank;
    }

    public String getRow5_name() {
        return row5_name;
    }

    public void setRow5_name(String row5_name) {
        this.row5_name = row5_name;
    }

    public String getRow5_price() {
        return row5_price;
    }

    public void setRow5_price(String row5_price) {
        this.row5_price = row5_price;
    }

    public String getRow6_rank() {
        return row6_rank;
    }

    public void setRow6_rank(String row6_rank) {
        this.row6_rank = row6_rank;
    }

    public String getRow6_name() {
        return row6_name;
    }

    public void setRow6_name(String row6_name) {
        this.row6_name = row6_name;
    }

    public String getRow6_price() {
        return row6_price;
    }

    public void setRow6_price(String row6_price) {
        this.row6_price = row6_price;
    }

    public String getRow7_rank() {
        return row7_rank;
    }

    public void setRow7_rank(String row7_rank) {
        this.row7_rank = row7_rank;
    }

    public String getRow7_name() {
        return row7_name;
    }

    public void setRow7_name(String row7_name) {
        this.row7_name = row7_name;
    }

    public String getRow7_price() {
        return row7_price;
    }

    public void setRow7_price(String row7_price) {
        this.row7_price = row7_price;
    }

    public String getRow8_rank() {
        return row8_rank;
    }

    public void setRow8_rank(String row8_rank) {
        this.row8_rank = row8_rank;
    }

    public String getRow8_name() {
        return row8_name;
    }

    public void setRow8_name(String row8_name) {
        this.row8_name = row8_name;
    }

    public String getRow8_price() {
        return row8_price;
    }

    public void setRow8_price(String row8_price) {
        this.row8_price = row8_price;
    }

    public String getRow9_rank() {
        return row9_rank;
    }

    public void setRow9_rank(String row9_rank) {
        this.row9_rank = row9_rank;
    }

    public String getRow9_name() {
        return row9_name;
    }

    public void setRow9_name(String row9_name) {
        this.row9_name = row9_name;
    }

    public String getRow9_price() {
        return row9_price;
    }

    public void setRow9_price(String row9_price) {
        this.row9_price = row9_price;
    }

    public String getRow10_rank() {
        return row10_rank;
    }

    public void setRow10_rank(String row10_rank) {
        this.row10_rank = row10_rank;
    }

    public String getRow10_name() {
        return row10_name;
    }

    public void setRow10_name(String row10_name) {
        this.row10_name = row10_name;
    }

    public String getRow10_price() {
        return row10_price;
    }

    public void setRow10_price(String row10_price) {
        this.row10_price = row10_price;
    }

    String row6_price;
    String row7_rank,row7_name,row7_price;
    String row8_rank,row8_name,row8_price;
    String row9_rank,row9_name,row9_price;
    String row10_rank,row10_name,row10_price;

}
