package enumControlllerTests;

public enum UserStatus {
    PENDING,
    ACTIVE,
    INACTIVE,
    DELETED;
}
