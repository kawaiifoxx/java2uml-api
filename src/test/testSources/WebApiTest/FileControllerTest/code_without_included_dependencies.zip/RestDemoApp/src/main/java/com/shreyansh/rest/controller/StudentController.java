package com.shreyansh.rest.controller;

import com.shreyansh.rest.entity.Student;
import com.shreyansh.rest.error.StudentErrorResponse;
import com.shreyansh.rest.exception.StudentNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentController {

    List<Student> students;

    @GetMapping("/students")
    public List<Student> getStudents() {
        return students;
    }

    @GetMapping("/students/{studentId}")
    public Student getStudent(@PathVariable int studentId) {

        if (studentId >= students.size() || studentId < 0) {
            throw new StudentNotFoundException("Student not found, (query is out of bounds) studentId passed is " + studentId);
        }

        return students.get(studentId);
    }

    @PostConstruct
    public void loadStudents() {
        students = new ArrayList<>();

        students.add(new Student("Shreyansh", "Gupta"));
        students.add(new Student("Daulesh", "Godbole"));
        students.add(new Student("Dipesh", "Verma"));
        students.add(new Student("Abhishek", "Kesarwani"));
    }

}
