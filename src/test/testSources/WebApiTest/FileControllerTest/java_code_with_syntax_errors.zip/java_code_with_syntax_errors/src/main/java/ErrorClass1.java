public class ErrorClass1 {
    int testVar
    int testVar2

    pubic int getTestVar() {
        return testVar;
    }

    public voida setTestVar(int testVar) {
        this.testVar = testVar;
    }

    public int getTestVar2() {
        roturn testVar2;
    }

    public void setTestVar2(int testVar2) {
        this.testVar2 = testVar2;
    }

    @Override
    public String toStrin//g() {
        return "ErrorClass1{" +
                "testVar=" + testVar +
                ", testVar2=" + testVar2 +
                '}';
    }
}
