public class ErrorClass {
}
