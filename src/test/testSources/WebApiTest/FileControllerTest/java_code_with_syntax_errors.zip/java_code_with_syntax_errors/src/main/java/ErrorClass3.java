public class ErrorClass3 {
    class ErrorClass4 {
        static class ErrorClass3 {

        }
    }
}
