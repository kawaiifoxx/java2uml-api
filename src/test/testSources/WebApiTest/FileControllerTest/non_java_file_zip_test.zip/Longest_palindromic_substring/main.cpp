#include <iostream>
#include <vector>

class Solution {
public:
    static std::string longestPalindrome(std::string &s) {
        if (s.empty())
            return "";
        int max_palindrome_length = 1;
        int max_palindrome_center = 1;
        int center_position = 2;
        int center_right_position = 2;


        std::vector<int> LPS(2 * s.size() + 1, 0);
        LPS[1] = 1;

        for (int current_right_position = 2; current_right_position < LPS.size(); ++current_right_position) {
            int current_left_position = 2 * center_position - current_right_position;
            int difference = center_right_position - current_right_position;

            bool expand = false;

            if (difference >= 0) {
                if (LPS[current_left_position] < difference ||
                    LPS[current_left_position] == difference && center_right_position == LPS.size() - 1) {
                    LPS[current_right_position] = LPS[current_left_position];
                } else if (LPS[current_left_position] == difference && center_right_position < LPS.size() - 1) {
                    expand = true;
                    LPS[current_right_position] = LPS[current_left_position];
                } else if (LPS[current_left_position] > difference) {
                    expand = true;
                    LPS[current_right_position] = difference;
                }
            } else {
                LPS[current_right_position] = 0;
                expand = true;
            }

            while (expand && current_right_position + LPS[current_right_position] < LPS.size() &&
                   current_right_position - LPS[current_right_position] > 0 &&
                   (((current_right_position + LPS[current_right_position] + 1) % 2 == 0) ||
                    s[(current_right_position + LPS[current_right_position] + 1) / 2] ==
                    s[(current_right_position - LPS[current_right_position] - 1) / 2]))
                LPS[current_right_position]++;

            if (LPS[current_right_position] > max_palindrome_length) {
                max_palindrome_length = LPS[current_right_position];
                max_palindrome_center = current_right_position;
            }

            if (center_right_position < current_right_position + LPS[current_right_position]) {
                center_position = current_right_position;
                center_right_position = current_right_position + LPS[current_right_position];
            }

        }

        int start = (max_palindrome_center - max_palindrome_length) / 2;

        return s.substr(start, max_palindrome_length);
    }
};

int main() {
    std::string test = "dabccbaxababbaba";
    std::cout << Solution::longestPalindrome(test);
    return 0;
}
