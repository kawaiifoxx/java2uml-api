public interface Test1 {
    void method1();
    void method2();
    void method3();
    void method4();
}
