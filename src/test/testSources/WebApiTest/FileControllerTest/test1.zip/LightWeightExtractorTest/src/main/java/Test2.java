import java.io.Serializable;

public class Test2 implements Test1, Serializable {

    int field1;
    int field2;
    int field3;


    @Override
    public void method1() {

    }

    @Override
    public void method2() {

    }

    @Override
    public void method3() {

    }

    @Override
    public void method4() {

    }
}
