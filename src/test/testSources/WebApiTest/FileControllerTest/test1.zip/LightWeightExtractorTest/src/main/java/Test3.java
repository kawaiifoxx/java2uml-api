public class Test3 {
    Test1 field1;
    Test2 field2;
    int field3;
    String field4;

    public Test3(Test1 field1, Test2 field2, int field3, String field4) {
        this.field1 = field1;
        this.field2 = field2;
        this.field3 = field3;
        this.field4 = field4;
    }

    public void method1(Test1 field1) {
    }

    public void method2(Test4 field5) {
    }
}
