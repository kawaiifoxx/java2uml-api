public class Test4 extends Test3{
    public Test4(Test1 field1, Test2 field2, int field3, String field4) {
        super(field1, field2, field3, field4);
    }
}
