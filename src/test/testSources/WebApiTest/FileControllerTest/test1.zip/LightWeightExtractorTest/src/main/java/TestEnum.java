public enum TestEnum {
    HIGH(3),
    MED(2),
    LOW(1);

    private final int val;

    TestEnum(int val) {
        this.val = val;
    }

    public int getVal() {
        return val;
    }
}
