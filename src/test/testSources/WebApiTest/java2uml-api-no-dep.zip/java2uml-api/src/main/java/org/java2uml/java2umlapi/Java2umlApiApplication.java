package org.java2uml.java2umlapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java2umlApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(Java2umlApiApplication.class, args);
    }

}
