package org.java2uml.java2umlapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java2umlApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
