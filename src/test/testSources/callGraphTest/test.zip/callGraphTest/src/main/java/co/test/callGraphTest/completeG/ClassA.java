package co.test.callGraphTest.completeG;

public class ClassA {
    private final ClassB classB = new ClassB();
    private final ClassC classC = new ClassC();
    private final ClassD classD = new ClassD();
    private final ClassE classE = new ClassE();

    //For Testing cyclic dependency recursion.
    public void methodA() {
        methodA();
        classB.methodB();
        classC.methodC();
        classD.methodD();
        classE.methodE();
    }
}
