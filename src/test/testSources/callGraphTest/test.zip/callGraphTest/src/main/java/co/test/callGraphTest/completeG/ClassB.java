package co.test.callGraphTest.completeG;

public class ClassB {
    private final ClassC classC = new ClassC();
    private final ClassA classA = new ClassA();
    private final ClassD classD = new ClassD();
    private final ClassE classE = new ClassE();


    //For Testing cyclic dependency recursion.
    public void methodB() {
        methodB();
        classA.methodA();
        classC.methodC();
        classD.methodD();
        classE.methodE();
    }
}
