package co.test.callGraphTest.completeG;

public class ClassC {
    private final ClassD classD = new ClassD();
    private final ClassA classA = new ClassA();
    private final ClassB classB = new ClassB();
    private final ClassE classE = new ClassE();


    //For Testing cyclic dependency recursion.
    public void methodC() {
        methodC();
        classA.methodA();
        classB.methodB();
        classD.methodD();
        classE.methodE();
    }
}
