package co.test.callGraphTest.completeG;

public class ClassE {
    private final ClassA classA = new ClassA();
    private final ClassB classB = new ClassB();
    private final ClassC classC = new ClassC();
    private final ClassD classD = new ClassD();


    //For Testing cyclic dependency recursion.
    public void methodE() {
        methodE();
        classA.methodA();
        classB.methodB();
        classC.methodC();
        classD.methodD();
    }
}
