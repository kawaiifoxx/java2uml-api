package co.test.callGraphTest.cyclicDep;

public class ClassA {
    private final ClassB classB = new ClassB();

    //For Testing cyclic dependency recursion.
    public void methodA() {
        classB.methodB();
    }
}
