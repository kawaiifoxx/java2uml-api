package co.test.callGraphTest.cyclicDep;

public class ClassB {
    private final ClassC classC = new ClassC();

    //For Testing cyclic dependency recursion.
    public void methodB() {
        classC.methodC();
    }
}
