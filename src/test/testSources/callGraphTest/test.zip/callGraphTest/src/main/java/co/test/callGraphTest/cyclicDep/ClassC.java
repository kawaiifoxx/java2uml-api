package co.test.callGraphTest.cyclicDep;

public class ClassC {
    ClassD classD = new ClassD();

    //For Testing cyclic dependency recursion.
    public void methodC() {
        classD.methodD();
    }
}
