package co.test.callGraphTest.cyclicDep;

public class ClassD {
    ClassE classE = new ClassE();

    //For Testing cyclic dependency recursion.
    public void methodD() {
        classE.methodE();
    }
}
