package co.test.callGraphTest.cyclicDep;

public class ClassE {
    ClassA classA = new ClassA();

    //For Testing cyclic dependency recursion.
    public void methodE() {
        classA.methodA();
    }
}
