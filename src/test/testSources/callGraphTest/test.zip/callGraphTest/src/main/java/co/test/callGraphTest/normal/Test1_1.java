package co.test.callGraphTest.normal;

public class Test1_1 {
    public void test1() {
    }
}
