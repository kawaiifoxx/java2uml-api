package co.test.callGraphTest.normal;

public class Test1_2 {
    public void test1() {
    }
}
