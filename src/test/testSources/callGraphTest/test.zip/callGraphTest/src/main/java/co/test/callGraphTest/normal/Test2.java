package co.test.callGraphTest.normal;

public class Test2 {
    private final Test1_1 test1_1 = new Test1_1();
    private final Test1_2 test1_2 = new Test1_2();

    public void test2() {
        test1_1.test1();
        test1_2.test1();
    }

}
