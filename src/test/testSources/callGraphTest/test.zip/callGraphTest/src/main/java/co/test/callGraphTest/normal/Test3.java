package co.test.callGraphTest.normal;

public class Test3 {
    private final Test2 test2 = new Test2();

    public void test3() {
        test2.test2();
    }

}
