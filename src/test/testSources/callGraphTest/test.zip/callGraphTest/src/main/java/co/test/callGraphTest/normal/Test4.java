package co.test.callGraphTest.normal;

public class Test4 {
    private final Test3 test3 = new Test3();

    public void test4() {
        test3.test3();
    }

}
