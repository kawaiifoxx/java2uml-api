package co.test.callGraphTest.normal;

public class Test5 {
    private final Test4 test4 = new Test4();

    public void test2() {
        test4.test4();
    }

}
