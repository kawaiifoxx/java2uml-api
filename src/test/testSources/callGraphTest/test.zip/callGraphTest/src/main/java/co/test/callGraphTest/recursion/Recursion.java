package co.test.callGraphTest.recursion;

public class Recursion {
    public void recurse() {
        recurse();
    }
}
